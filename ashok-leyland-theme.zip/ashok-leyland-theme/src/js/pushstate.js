 
  var load = function (url) {
        $.get(url).done(function (data) {
            $("#content").html(data);
        })
    };

   // $(document).on('click', '.xxxzzzz', function (e) {
    $('.xxxzzzz').click(function(){
      //alert('asdf');
        e.preventDefault();

        var $this = $(this),
            url = $this.attr("href"),
            title = $this.text();

        history.pushState({
            url: url,
            title: title
        }, title, url);

        document.title = title;

        load(url);
    });

    $(window).on('popstate', function (e) {
        var state = e.originalEvent.state;
        if (state !== null) {
            document.title = state.title;
            load(state.url);
        } else {
            document.title = 'World Regions';
            $("#content").empty();
        }
    });
 
 $(function () {
        $("#button1").click(function () {
            ChangeUrl('Page1', 'Page1.htm');
        });
        $("#button2").click(function () {
            ChangeUrl('Page2', 'Page2.htm');

        });
        $("#button3").click(function () {
            ChangeUrl('Page3', 'Page3.htm');
        });
