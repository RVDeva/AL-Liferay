AUI().ready(
  function(){
    var $ = AUI.$;
    function getScrollBarWidth () {
      var inner = document.createElement('p');
      inner.style.width = "100%";
      inner.style.height = "200px";

      var outer = document.createElement('div');
      outer.style.position = "absolute";
      outer.style.top = "0px";
      outer.style.left = "0px";
      outer.style.visibility = "hidden";
      outer.style.width = "200px";
      outer.style.height = "150px";
      outer.style.overflow = "hidden";
      outer.appendChild (inner);

      document.body.appendChild (outer);
      var w1 = inner.offsetWidth;
      outer.style.overflow = 'scroll';
      var w2 = inner.offsetWidth;
      if (w1 == w2) { w2 = outer.clientWidth; }
      document.body.removeChild (outer);
      
      return (w1 - w2);
    };
    var scrollWidth = getScrollBarWidth();
    var winWidth = $(window).width();  
    $(document).ready(function(){
      $('html').animate({
      scrollTop: $('html')[0].scrollHeight}, 80000);
      //return false;
    }); 
    $(document).mousemove(function(e){
      var checkCursor = winWidth - e.pageX;
      if(checkCursor<=0){
        $('html').stop()
      }
    });
    $(window).bind('mousewheel', function(e){
      if(e.originalEvent.wheelDelta /120 > 0) {
        $('html').stop()
      }
      else{
        $('html').stop()
      }
    });
    $('.historyTimeline').mouseenter(function() {
      $('html').stop()
    });
    $('.historyTimeline').mouseleave(function() {
       $('html').animate({
      scrollTop: $('html')[0].scrollHeight}, 80000);
    });
    $('body' ).bind( "tap", tapHandler );
    function tapHandler( event ){
      $('html').stop()
    }
    $.fn.scrollEnd = function(callback, timeout) {          
      $(this).scroll(function(){
        var $this = $(this);
        if ($this.data('scrollTimeout')) {
          clearTimeout($this.data('scrollTimeout'));
        }
        $this.data('scrollTimeout', setTimeout(callback,timeout));
      });
    };
    $(window).scrollEnd(function(){
        $('html').stop()
    }, 1000);
  }
);

