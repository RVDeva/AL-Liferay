Liferay.on(
	'allPortletsReady',
	/*
	This function gets loaded when everything, including the portlets, is on
	the page.
	*/
	function() {

		var $ = AUI.$;

		/* Search */

		var searchbtn = $('.search-btn');

        searchbtn.on(
            'click',
            function (event) {
                event.preventDefault();
                event.stopPropagation();
                if ($(this).hasClass('active')) {
	                $(this).removeClass('active');
	                $('#header-search-form').removeClass('active');
	                $('#header-search-form').slideUp('fast', function(){
	                	$('#header-search-form .search-input').val('');
	                });
	                $('#search-backdrop').fadeOut('fast', function(){
	                	$('#search-backdrop').removeClass('active');
	                });
	            } else {
	            	$(this).addClass('active');
	                $('#header-search-form').addClass('active');
                	$('#header-search-form').slideDown('fast', function(){
	                	$('#header-search-form .search-input').focus();
	                });
	                $('#search-backdrop').fadeIn('fast', function(){
	                	$('#search-backdrop').addClass('active');
	                });
	            }
            }
        );

        $(window).on('click', function(e){
        	if (searchbtn.hasClass('active')) {
        		if ($(e.target).parents('#header-search-form').length <= 0) {
		        	$('.search-btn, #header-search-form').removeClass('active');
	                $('#header-search-form').slideUp('fast', function(){
	                	$('#header-search-form .search-input').val('');
	                });
             		$('#search-backdrop').fadeOut('fast', function(){
	                	$('#search-backdrop').removeClass('active');
	                });
	            }
	        }
        });

		/* End */

		$(".popupOverlay").click(function(ev) {
			$('body').css({
				overflow: 'visible'
			});
			$(".popupOverlay ").fadeOut();
			$(".loginWrapper ").fadeOut();
			$('.popupVideo').html('');
			$('.subscribeBox').fadeOut();
			$('.serviceproductsEnquiryBox').fadeOut();
			$('.partsEnquiryBox').fadeOut();

		});
		$(".subscribePopOver").click(function(ev) {
			$('body').css({
				overflow: 'visible'
			});
			$(".subscribePopOver ").fadeOut();
			$(".loginWrapper ").fadeOut();
			$('.popupVideo').html('');
			$('.subscribeBox').fadeOut();

		});
		$(".serviceproductsEnquiryPopOver").click(function(ev) {
			$('body').css({
				overflow: 'visible'
			});
			$(".serviceproductsEnquiryPopOver ").fadeOut();
			$(".loginWrapper ").fadeOut();
			$('.popupVideo').html('');
			$('.serviceproductsEnquiryBox').fadeOut();
			$('.partsEnquiryBox').fadeOut();

		});
		$(".partsEnquiryPopOver").click(function(ev) {
			$('body').css({
				overflow: 'visible'
			});
			$(".partsEnquiryPopOver ").fadeOut();
			$(".loginWrapper ").fadeOut();
			$('.popupVideo').html('');
			$('.serviceproductsEnquiryBox').fadeOut();
			$('.partsEnquiryBox').fadeOut();

		});
		$('.loginToggle').click(function(){
			$(".popupOverlay ").fadeIn();
			$('.loginWrapper').fadeIn();
		});
		$('.subscribeFooter').click(function(){
			$(".subscribePopOver ").fadeIn();
			$('.subscribeBox').fadeIn();
		});
		$('#serviceProductsBtn').click(function(){
			$('body').css({overflow: 'hidden'});
			$(".serviceproductsEnquiryPopOver ").fadeIn();
			$('.serviceproductsEnquiryBox').fadeIn();
		});
		$('#partsEnquiryBtn').click(function(){
			$('body').css({overflow: 'hidden'});
			$(".partsEnquiryPopOver ").fadeIn();
			$('.partsEnquiryBox').fadeIn();
		});
		$('#businessEnquiryBtn').click(function(){
			$('body').css({overflow: 'hidden'});
			$(".serviceproductsEnquiryPopOver ").fadeIn();
			$('.serviceproductsEnquiryBox').fadeIn();
		});
		$('.popupConten , .popupConten  *  ').on('click', function(ev) {
			ev.stopPropagation();
		});
		$('.home-block-video a.wrapbox, .videotoggal').click(function(e) {
			e.stopPropagation();
			$thisParent = $($(this).parents('.home-block-video'));
			$thisParent.find('.popupOverlay').fadeIn();
			if( $thisParent.find('.popupConten').length > 0 ) {
				$thisParent.find('.popupConten').fadeIn();
			}
			$('body').css({overflow: 'hidden'});
			var videoUrl = $thisParent.find('.videotoggal').attr('data-ref')
			if (videoUrl.indexOf("youtube") >= 0) {
				$thisParent.find('.popupVideo').html('<iframe src='+videoUrl+' frameborder="0" allowfullscreen></iframe>');
				$thisParent.find('.popupVideo').css("paddingTop","55%");
			} else {
				$thisParent.find('.popupVideo').html('<video class="localVideoPlay" controls autoplay><source src='+videoUrl+' type="video/mp4">Not Supported</video>');
				$thisParent.find('.popupVideo').css("paddingTop","5%");
			}
			return false;
		});

		if ($('*').hasClass('clSlider')) {
			var countli = $('.clSlider .listItem').length;
			if( countli <= 3){
				$('.clSlider').slick({
				infinite: false,
				slidesToShow: 1,
				slidesToScroll: 1,
				vertical: true,
				centerMode: true,
				focusOnSelect: true,
				arrows: false,
				responsive: [{
					breakpoint: 1034,
					settings: {
						vertical: false,
						centerMode: true,
						variableWidth: true,
						slidesToShow: 1,
				slidesToScroll: 1,
					}
				}, ]
			});

			}
			else{
				$('.clSlider').slick({
				infinite: true,
				slidesToShow: 3,
				slidesToScroll: 1,
				vertical: true,
				centerMode: true,
				focusOnSelect: true,
				arrows: false,
				responsive: [{
					breakpoint: 1034,
					settings: {
						vertical: false,
						centerMode: true,
						variableWidth: true,
						slidesToShow: 3,
				slidesToScroll: 1,
					}
				}, ]
			});
			}
		}

		$('.clMenuToggle').click(function() {
			$(this).toggleClass('active');
			$('.clLeftwrap').toggleClass('closeMegamenu');
			$('.clRightSideContenWrap ').addClass('smootheffect');
			$('.clRightSideContenWrap ').toggleClass('contenCenter');
		});
		$('.mobDropMegamenu').click(function() {
			$('.mobilenavigation').addClass('activeSl');
			$('.backNavigation').addClass('active')
		});

		$('.mobDropdown').click(function() {
			if ($(this).hasClass('active')) {
				$(this).removeClass('active');
				$(this).next('ul').removeClass('active');
			} else {
				$('.mobDropdown').removeClass('active');
				$('.mdropdwonMenu').removeClass('active');
				$(this).addClass('active');
				$(this).next('ul').addClass('active');
			}
		});
		$('.backNavigation').click(function() {
			$('.mobilenavigation').removeClass('activeSl');
			if ($(this).hasClass('active')) {
				$('.backNavigation').removeClass('active');
			} else {
				$('.mobileMenuWrapper').removeClass('menuShow');
				$('body').css({ overflow: '' });
				$('.menuoverly').hide();
			}
		});
		$('.navbar-custome-toggle').click(function() {
			$('body').css({ overflow: 'hidden' });
			$('.mobileMenuWrapper').addClass('menuShow');
			$('.menuoverly').show();
		});

		$(".menuoverly").click(function(ev) {
			$('.mobileMenuWrapper').removeClass('menuShow');
			$('body').css({ overflow: '' });
			$(this).hide();
		});

		$('.mobileClose').click(function(){
			   $(".popupOverlay ").fadeOut();
			   $(".subscribePopOver ").fadeOut();
			   $(".serviceproductsEnquiryPopOver ").fadeOut();
			   $(".partsEnquiryPopOver ").fadeOut();
			$(".loginWrapper ").fadeOut();
		});
		$('#servideMobileMenu').change(function(){
		   var selectTarget =  $(this).val();
		   $('.tab-content .tab-pane').removeClass('show active');
		   $(selectTarget).addClass('show active');
		});
		$('#changePageSelect').change(function(){
		  // var selectTarget =  $(this).val();
		  /* $('.tab-content .tab-pane').removeClass('show active');
		   $(selectTarget).addClass('show active');
		   console.log(selectTarget);*/
		   var url = $(this).val(); // get selected value
				  if (url) { // require a URL
					  window.location = url; // redirect
				  }
				  return false;
		});


		$(".lcv-ready-to-use .reatytoTab a").click(function(){
			var tabId = $(this).attr("data-ref");
			$(this).parent().parent().find('a').removeClass('active');
			$(this).addClass('active');
			$(".lcv-ready-to-use .tab-content").find('div').removeClass('active show in');
			$(".lcv-ready-to-use .tab-content").find("#"+tabId).addClass("active show");

		});

		function recallAllFunctions() {
			$(".popupOverlay").click(function(e) {
	    		$('body').css({overflow: ''});
	    		$('.popupConten').fadeOut();
	    		$(".popupOverlay ").fadeOut();
	    		$(".loginWrapper ").fadeOut();
	    		$('.popupVideo').html('');
				$('.subscribeBox').fadeOut();
				$('.serviceproductsEnquiryBox').fadeOut();
				$('.partsEnquiryBox').fadeOut();
	    		$('.salesPopup').fadeOut();
			});
	    	$('#sales-update-select').change(function() {
	        	if ($(this).val() !== "0") {
		            $('.popupOverlay').fadeIn();
		            var targetselect = $(this).val();
		            $('#' + targetselect).fadeIn();
		        }
		    });
	  	}
	    recallAllFunctions();

		/* Function to change URL and push history state */
		function changeTheURL(obj, title, dataHref) {
			history.pushState(obj, title, dataHref);
		}

		/* Function triggers on clicking on browser back/forward button	*/
		$(window).on('popstate', function (e) {
			var state = e.originalEvent.state;
			/* Coming to Circle*/
			if(state) {
				if ( state.pageType && state.isInnerPage !== true ) {
					/* Going Back to Circle from Semi-circle */
					if( $('.customersMainMenu').length > 0 ) {
						$('.clRightSideContenWrap').removeClass('showconten');
						$('.menuBorderani').removeClass('startAnimation');
						$('.menuImageToggle li').removeClass('active');
						$('.cutomerListMenu').removeClass('active');
						setTimeout(function(){
							$('.customersMainMenu').removeClass('moveLeft');
						}, 1000);
						return;
					} else {
						/* In case of Refresh or direct hit */
						location.assign(history.state.url);
					}
				}
				if ( state.pageType && state.isInnerPage && $('.customersMainMenu').length > 0 ) {
					/* Coming to Semi-circle from actual circle page when InnerPage state is true */
					location.assign(history.state.url);
					return;
				}
				if (state !== null && state.element) {
					/* When history is available and have reference to element in state object */
					var menuImgLi = state.element;
					var attrDataHref = state.url;
					$(".clRightSideContenWrap ").load( attrDataHref + ' #layout-column_column-2',	function() {
							$('.customersMainMenu').addClass('moveLeft');
							$('.menuBorderani').addClass('startAnimation');
							$('.cutomerListMenu').addClass('active');
							$('.clRightSideContenWrap').addClass('showconten');
							$('.menuImageToggle li').removeClass('active');
							$('.' + menuImgLi).addClass('active');
							$('.clSlider').slick('slickGoTo', $('a[data-target="' + menuImgLi + '"]:not(.slick-cloned)').attr('data-slick-index'));
							recallAllFunctions();
						}
					);
					return;
				}
			}
		});

		/* Click event on circle navigation link */
		$('.slideLink').on('click', function() {
			var slideTarget = $(this).attr('rel');
			if (slideTarget) {
				$('a[data-target="' + slideTarget + '"]:not(.slick-cloned)').trigger("click");
				$('.customersMainMenu').addClass('moveLeft');
				$('.menuBorderani').addClass('startAnimation');
				$('.cutomerListMenu').addClass('active');
				$('.clRightSideContenWrap').addClass('showconten');
			}
		});

		/* Click event when clicked on side circle navigation */
		$('#circleSideNav').on('click', '.listItem', function(e) {
			var menuImgLi = $(this).attr('data-target');
			var attrDataHref = $(this).attr('data-href');
			if(menuImgLi && attrDataHref && (location.pathname).indexOf(attrDataHref) === -1) {
				var stateObj = {
					url: attrDataHref,
					title: document.title,
					element: menuImgLi
				};
				$(".clRightSideContenWrap ").load( attrDataHref + ' #layout-column_column-2',
					function() {
						$('.menuImageToggle li').removeClass('active');
						$('.' + menuImgLi).addClass('active');
						changeTheURL(stateObj, menuImgLi, attrDataHref);
						recallAllFunctions();
					}
				);
			}
		});

		/*
			Store the initial content so we can revisit it later
			If Circular landing page replace History state on page load
		*/
		if( $('#landingContentWrapper').attr('data-landing-page')  == 'true' ) {
			history.replaceState({
				url: document.location.href,
				title: document.title,
				pageType: document.location.href.split('/').pop()
			}, document.title, Liferay.ThemeDisplay.getLayoutRelativeURL());
		}

		/* If inner page replace History state on page load	*/
		if( $('#innerPageContentWrapper').attr('data-inner-page') == 'true' ) {
			var listLiArray = $('#circleSideNav a.listItem:not(.slick-cloned)');
			for (var i = 0, len = listLiArray.length; i < len; i++) {
				if ($(listLiArray[i]).attr('data-href') && location.pathname.indexOf($(listLiArray[i]).attr('data-href')) !== -1){
					history.replaceState({
						url: document.location.href,
						title: document.title,
						pageType: document.location.href.split('/').pop(),
						isInnerPage: true,
						element: $(listLiArray[i]).attr('data-target')
					}, document.title, Liferay.ThemeDisplay.getLayoutRelativeURL());
					$('.clSlider').slick('slickGoTo', $(listLiArray[i]).attr('data-slick-index'));
					$('.' + $(listLiArray[i]).attr('data-target')).addClass('active');
				}
			}
		}
		function slickResizeFun(event, slick, currentSlide, nextSlide) {
			$('.slick-current').trigger('click');
		}
		/* Trigger click on Page load/reload on Circular Navigation */
		if ($('body').width() < 1034) {
			if ($('#landingContentWrapper').length > 0) {
				$('a.slideLink[rel]:first').trigger('click');
			}
			if ($('.clSlider').length > 0) {
				$('.clSlider').on('afterChange', slickResizeFun);
			}
			$('.customersMainMenu').addClass('moveLeft');
			$('.menuBorderani').removeClass('startAnimation');
			$('.cutomerListMenu').addClass('active');
			$('.clRightSideContenWrap').addClass('showconten');
		}

		/* Trigger click on Window resize */
		$( window ).resize(function() {
			if ($('body').width() < 1034) {
				$('a.slideLink[rel]:first').trigger('click');
				if ($('.clSlider').length > 0) {
					$('.clSlider').on('afterChange', slickResizeFun);
				}
				$('.customersMainMenu').addClass('moveLeft');
				$('.cutomerListMenu').addClass('active');
				$('.menuBorderani').removeClass('startAnimation');
				$('.clRightSideContenWrap').addClass('showconten');
			}
			else{
				if ($('.clSlider').length > 0) {
					$('.clSlider').off('afterChange', slickResizeFun);
				}
				if($('.menuImageToggle li').hasClass('active')){
					$('.menuBorderani').addClass('startAnimation');
				}
			}
		});
	}
);

AUI().ready(
	function(){

		var resizeTimer;
		var archiveDiv = $('#archiveDivWithJS');
		var policiesHead = $("#policiesHead");
		$('#content').css({'margin-top': $('header').height()});
		$(window).on('resize', function(e) {
			clearTimeout(resizeTimer);
			resizeTimer = setTimeout(function() {
				$('#content').css({'margin-top': $('header').height()});
				if( archiveDiv.length > 0 && policiesHead.length > 0 ) {
					archiveDiv.css('right',document.body.clientWidth - (policiesHead.offset().left + policiesHead.width()));
				}
			}, 250);
		});
		if( archiveDiv.length > 0 && policiesHead.length > 0 ) {
			archiveDiv.css({
				right:document.body.clientWidth - (policiesHead.offset().left + policiesHead.width()),
				visibility: 'visible'
			});
		}

		// Single-Product
		if( typeof $.fn.bootstrapSlider === "function" ) {
			$("#ex8").bootstrapSlider({
				formatter: function(value) { return 'Rs. ' + value; }
			});
			$("#ex9").bootstrapSlider({
				formatter: function(value) { return value + ' %'; }
			});
			$("#ex10").bootstrapSlider({
				formatter: function(value) { return value + ' Year '; }
			});
		}
		$('.spMenutop li a').click(function(e){
				$(this).parent().parent().find('a').removeClass('active');
				$(this).addClass('active');
		});

		$('#sigleproductmobile').change(function(){
			var selectTarget =  $(this).val();
			$('.tab-content .tab-pane').removeClass('show active');
			$(selectTarget).addClass('show active');
		});

		$('.single-product-100').closest('#content').addClass('single-product-100-wrapper');

		$('.lvcSubmenu li a').click(function(e){
			$(this).parent().parent().find('a').removeClass('active');
			$(this).addClass('active');
		});

		// LCV Colors Tab Color Carousel
	    $('.slider-for').slick({
	        slidesToShow: 1,
	        slidesToScroll: 1,
	        arrows: true,
	        fade: true,
	        infinite: false,
	        asNavFor: '.slider-nav'
	    });
	    $('.slider-nav').slick({
	        slidesToShow: 4,
	        slidesToScroll: 1,
	        asNavFor: '.slider-for',
	        dots: false,
	        arrows: false,
	        centerMode: true,
	        focusOnSelect: true,
	        infinite: false,
	        responsive: [{
	                breakpoint: 768,
	                settings: {
	                    slidesToShow: 1,
	                }
	            },
	        ]
	    });
		$(document).on('click', '.spMenutop li a', function(e){
		    $('#vis1').css('visibility', 'hidden');
		    setTimeout(function() {
	            $(".slider-for").slick('refresh');
	        	$(".slider-nav").slick('refresh');
	        	$(".bannerSlider").slick('refresh');
	        	$('#vis1').css('visibility', 'visible');
		    }, 300);
		});

		$('.featureList li a').click(function(){
			var targeImg = $(this).attr('data-ref');
			$('.productFeaturs div ').hide();
			$(targeImg).fadeIn();
		});
		/* Product Dost End */
	}
);